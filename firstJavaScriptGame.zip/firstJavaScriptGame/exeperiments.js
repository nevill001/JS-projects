let num1 = 1;
let num2 = 2;
let num3 = 3;
let num4 = 4;
let num5 = num1;
let num6 = num2;
let num7 = num3;
let num8 = num4;
let abc1 = Array(num1, num2, num3, num4, num1, num2, num3, num4);
console.log(abc1);
for (let i = 0; i < 8; i++) {
  let abc2 = abc1.length;
  let number = Math.floor(Math.random() * abc2);
  let number2 = abc1.splice(number, 1);
  console.log(number2, abc1);
}
let argus = ["abx", "abc"];
if (argus[argus.length - 1] === argus[argus.length - 2]) {
  console.log("!True!");
}
