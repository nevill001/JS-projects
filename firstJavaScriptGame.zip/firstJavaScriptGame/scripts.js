const start =
  document.querySelector(".create"); /*Объявление кнопки для старта новой игры*/
const lista =
  document.querySelectorAll(
    ".itemCard"
  ); /*Объявление секции для карточек (туда будут помещатся наши картинки, которые мы позже создадим)*/
const stepCounter = document.querySelector(".spanPannel"); /* */

const elem1 =
  document.createElement(
    "img"
  ); /*Создание элементов!!! Помните объект в js - уникальный, повторно использовать созданный элемент не получится*/
let elem2 = document.createElement("img");
let elem3 = document.createElement("img");
let elem4 = document.createElement("img");
let elem5 = document.createElement("img");
let elem6 = document.createElement("img");
let elem7 = document.createElement("img");
/*Создание элемеентов карточек*/
elem1.src = "https://picsum.photos//id//11//160//230";
elem1.className = "imgCard1";
elem1.id = "id1";
elem2.src = "https://picsum.photos//id//13//160//230";
elem2.className = "imgCard1";
elem2.id = "id2";
elem3.src = "https://picsum.photos//id//14//160//230";
elem3.className = "imgCard1";
elem3.id = "id3";
elem4.src = "https://picsum.photos//id//12//160//230";
elem4.className = "imgCard1";
elem4.id = "id4";
elem5.src = "https://picsum.photos//id//15//160//230";
elem5.className = "imgCard1";
elem5.id = "id5";
elem6.src = "https://picsum.photos//id//16//160//230";
elem6.className = "imgCard1";
elem6.id = "id6";
elem7.src = "https://picsum.photos//id//29//160//230";
elem7.className = "imgCard1";
elem7.id = "id7";
let elem8 = document.createElement("img");
let elem9 = document.createElement("img");
let elem10 = document.createElement("img");
let elem11 = document.createElement("img");
let elem12 = document.createElement("img");
let elem13 = document.createElement("img");
let elem14 = document.createElement("img");
/*Создание их дубликатов!!! Идентефикатор одинаковых ресунков должен совпадать!!!*/
elem8.src = "https://picsum.photos//id//11//160//230";
elem8.className = "imgCard2";
elem8.id = "id1";
elem9.src = "https://picsum.photos//id//13//160//230";
elem9.className = "imgCard2";
elem9.id = "id2";
elem10.src = "https://picsum.photos//id//14//160//230";
elem10.className = "imgCard2";
elem10.id = "id3";
elem11.src = "https://picsum.photos//id//12//160//230";
elem11.className = "imgCard2";
elem11.id = "id4";
elem12.src = "https://picsum.photos//id//15//160//230";
elem12.className = "imgCard2";
elem12.id = "id5";
elem13.src = "https://picsum.photos//id//16//160//230";
elem13.className = "imgCard2";
elem13.id = "id6";
elem14.src = "https://picsum.photos//id//29//160//230";
elem14.className = "imgCard2";
elem14.id = "id7";
let gameWin; /* */
let gameArray =
  Array(); /*Игровой массив, для подсчета ходов, и для сравнения элементов*/
let gameCounter = 0; /*Счетчик для цикла*/
let itemStorage; /*Объявления переменной где будет хранится предыдущий елемент по которому мы кликали*/
let clickCounter;

function startNewGame() {
  stepCounter.innerHTML = "00"; /*Счетчик ходов обнуляется*/
  gameArray = Array(); /*Игровой массив обнуляется*/
  let pictureArray = [
    /*Создаем массив из картинок-елементов*/ elem1,
    elem2,
    elem3,
    elem4,
    elem5,
    elem6,
    elem7,
    elem8,
    elem9,
    elem10,
    elem11,
    elem12,
    elem13,
    elem14,
  ];
  for (let item of lista) {
    /*Проходим по каждому нашему контейнеру где будут содеражстя карточки*/
    /*Запоняем наше игровое поле рандомно*/
    let randomNumber = Math.floor(Math.random() * pictureArray.length);
    item.appendChild(
      pictureArray[randomNumber]
    ); /*нашему контейнеру присваиватеся случайная карточка*/
    let remoovedPicture = pictureArray.splice(
      randomNumber,
      1
    ); /*Карточка что мы присвоили удаляется из списка*/
  }
  let pictures =
    document.querySelectorAll(".imgCard1"); /*Выбираем все наши карточки*/
  for (let itemPicture of pictures) {
    itemPicture.style.opacity = "0"; /*Делаем карточки снова невидимомыми*/
  }
  let pictures2 = document.querySelectorAll(".imgCard2");
  for (let itemPicture of pictures2) {
    itemPicture.style.opacity =
      "0"; /*Возвращаем все картинки в невидимое состояние*/
  }
  gameCounter = 0;
  gameWin = 0;
  clickCounter = 0;
}

function game(evt) {
  if (gameWin > 6) {
    stepCounter.innerHTML =
      "WIN"; /*Если условие выполнено и мы угадали карточки, вместо подсчета ходов выводится сообщение*/
  }
  if (
    evt.target.classList.contains("imgCard1") ||
    evt.target.classList.contains("imgCard2")
  ) {
    gameCounter++;
    clickCounter++; /*подсчет кликов*/
    stepCounter.innerHTML = `${clickCounter}`.padStart(
      2,
      "0"
    ); /*Это выравниевание строки, метод добавляет знак 0 если длина строки менее 2*/
    evt.target.style.opacity = "1";
    console.log(gameCounter);
    if (gameCounter > 1) {
      if (
        evt.target.id === itemStorage.id &&
        evt.target.className !== itemStorage.className
      ) {
        console.log("good");
        gameWin++;
      } else {
        console.log("delete");
        setTimeout(
          (nestedFunc = () => {
            evt.target.style.opacity = "0"; /*оБНУЛЯЕТ ВИДИМОСТИ*/
            itemStorage.style.opacity = "0";
          }),
          3000
        );
      }
    }
    if (gameCounter < 2) {
      /*!!!!ВНИМАНИЕ!!! ОБРАТИТЕ ВНИМАНИЕ КАК JS ОБРАБАТЫВАЕТ КОД!!!!*/
      itemStorage =
        evt.target; /*!!!Получение ссылки на объект если не было сделано кликов!!!!*/
    } else {
      gameCounter = 0; /*В ПРОТИВНОМ СЛУЧАЕ ССЫЛКУ НА ОБЪЕКТ МЫ НЕ ПОЛУЧАЕМ СЧЕТЧИК ОБНУЛЯЕТСЯ*/
    }
  }
}

start.addEventListener("click", startNewGame);
document.addEventListener("click", game);
