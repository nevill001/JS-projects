import { Player } from "./scripts/classes/player.js";
import {
  level_concreteBlocksArray,
  playerBlocksArray,
  level_brickBlocksArray,
  enemyBlocksArray,
  spaunerBlocksArray,
  starBlocksArray,
} from "./scripts/levels/level_1.js";
import { ConcreteBlock } from "./scripts/classes/concreteBlock.js";
import { distanceBeetwenTwoPoints } from "./scripts/utils/distance.js";
import { distanceForCollision } from "./scripts/utils/distance.js";
import { Shoots } from "./scripts/classes/shoots.js";
import { BrickWals } from "./scripts/classes/brikc_wals.js";
import { EnemyBasick } from "./scripts/classes/enemyBasick.js";
import { Spauner } from "./scripts/classes/spauner.js";
import { Stars } from "./scripts/classes/stars.js";
/**/

//TODO: receive the image and object from site
const winner = document.querySelector("#win");
const over = document.querySelector("#over");
const restart = document.querySelector("#res");

/*Задаем полотно для рисования*/
const canvas = document.querySelector("canvas");
canvas.width = 600;
canvas.height = 600;
/*Метод для получения контекста и визуализации изображения*/
const context = canvas.getContext("2d");

/*Задаем переменную с помощью которой будем ссылатся на класс игрока*/
let player;
let animation_game_over;
let blocksArray = [];
let shoots = [];
let enemy = [];
let spauners = [];
let stars = [];
const enemy_limit = 6;

function restartGame() {
  let blocksArray = [];
  let shoots = [];
  let enemy = [];
  let spauners = [];
  let stars = [];
  if (animation_game_over) {
    cancelAnimationFrame(animation_game_over);
  }
  mainFunction();
}

/*Функция при старте игры*/
function mainFunction() {
  init();
  animate();
}

function createShoots(object) {
  let x = object.x;
  let y = object.y;
  let destination = object.imageLenght;
  if (destination === 0) {
    y -= 20;
  }
  if (destination === 1) {
    y += 20;
  }
  if (destination === 2) {
    x -= 20;
  }
  if (destination === 3) {
    x += 20;
  }
  shoots.push(new Shoots(x, y, destination, context));
}

function spawnenemies() {
  if (enemy.length < enemy_limit) {
    let index = Math.floor(Math.random() * spauners.length);
    let object = spauners[index];
    enemy.push(new EnemyBasick(object.x, object.y, context));
  }
}

/*Функция где мы создаем наш танк и нициализируем основные параметры*/
function init() {
  player = new Player(
    playerBlocksArray[0][0],
    playerBlocksArray[0][1],
    context
  );
  enemyBlocksArray.forEach((elem) => {
    enemy.push(new EnemyBasick(elem[0], elem[1], context));
  });
  /*Переделать класс*/
  level_concreteBlocksArray.forEach((elem) => {
    blocksArray.push(new ConcreteBlock(elem[0], elem[1], context));
    // concreteBlocks.push(new ConcreteBlock(elem[0], elem[1], context));
  });
  level_brickBlocksArray.forEach((elem) => {
    blocksArray.push(new BrickWals(elem[0], elem[1], context));
    // brickBlocks.push(new BrickWals(elem[0], elem[1], context));
  });
  spaunerBlocksArray.forEach((elem) => {
    spauners.push(new Spauner(elem[0], elem[1], context));
  });
  starBlocksArray.forEach((elem) => {
    stars.push(new Stars(elem[0], elem[1], context));
  });
  stars[0].change();

  const spawnInterval = setInterval(spawnenemies, 7000);

  addEventListener("keydown", (event) => {
    if (event.code === "Space") {
      createShoots(player);
    }
  });
}

function animate() {
  animation_game_over = requestAnimationFrame(animate);
  /*Вызываем метод для очистки холста*/
  //TODO: Clear Canvas
  context.clearRect(0, 0, canvas.width, canvas.height);
  //TODO:Проверка условий окончания игры:
  if (player.health < 1) {
    cancelAnimationFrame(animation_game_over);
    over.style.display = "block";
    clearInterval(spawnInterval);
  }
  stars.forEach((elem) => {
    if (
      elem.imageStep === 2 &&
      distanceBeetwenTwoPoints(player.x, player.y, elem.x, elem.y) < 5
    ) {
      cancelAnimationFrame(animation_game_over);
      winner.style.display = "block";
      clearInterval(spawnInterval);
    }
  });
  //TODO: Work with arrays and drawing backFon
  enemy = enemy.filter((elem) => elem.health > 0);
  spauners = spauners.filter((elem) => elem.health > 0);
  spauners.forEach((elem) => {
    elem.draw();
  });
  stars.forEach((elem) => elem.draw());
  //TODO: Renedering shoots
  shoots.forEach((elem) => shooting(elem));
  //TODO: Rendering player and enemy
  enemy.forEach((elem) => enemyIsMooving(elem));
  playerMooving();
  //TODO: Rendering the elements of blocks
}

mainFunction();

//! this is a collision function (require an argument as class Object: for axample player) whith blocks
function playerMooving() {
  let previousX = player.x;
  let previousY = player.y;
  player.updatePosition();
  //! Brick Blocks mod
  blocksArray.forEach((elem) => {
    if (distanceForCollision(player, elem) === "x") {
      player.x = previousX;
    }
    if (distanceForCollision(player, elem) === "y") {
      player.y = previousY;
    }
    elem.draw();
  });
  blocksArray = blocksArray.filter((elem) => elem.health > 0);
  player.draw();
}

function enemyIsMooving(object) {
  let previousX = object.x;
  let previousY = object.y;
  object.update();
  blocksArray.forEach((elem) => {
    if (distanceForCollision(object, elem) === "x") {
      object.x = previousX;
      object.imageLenght++;
    }
    if (distanceForCollision(object, elem) === "y") {
      object.y = previousY;
      object.imageLenght++;
    }
  });
  if (object.x === player.x) {
    if (object.y - player.y > 0) {
      object.imageLenght = 0;
    } else {
      object.imageLenght = 1;
    }
    if (object.mooving % 100 === 0) {
      createShoots(object);
    }
  }
  if (object.y === player.y) {
    if (object.x - player.x > 0) {
      object.imageLenght = 2;
    } else {
      object.imageLenght = 3;
    }
    if (object.mooving % 100 === 0) {
      createShoots(object);
    }
  }
}

function shooting(elem) {
  elem.update();
  enemy.forEach((item) => {
    if (distanceBeetwenTwoPoints(elem.x, elem.y, item.x, item.y) < 15) {
      item.hit();
      shoots.splice(elem);
    }
  });
  if (distanceBeetwenTwoPoints(player.x, player.y, elem.x, elem.y) < 15) {
    player.hit();
    shoots.splice(elem);
  }
  blocksArray.forEach((item) => {
    if (distanceBeetwenTwoPoints(elem.x, elem.y, item.x, item.y) < 15) {
      item.hit();
      shoots.splice(elem);
    }
  });
  spauners.forEach((item) => {
    if (distanceBeetwenTwoPoints(elem.x, elem.y, item.x, item.y) < 15) {
      item.hit();
      shoots.splice(elem);
    }
  });
}
