export function distanceBeetwenTwoPoints(x1, y1, x2, y2) {
  const xDiff = x1 - x2;
  const yDiff = y1 - y2;
  /*Высчитываем гипотенузу с помозью метода*/
  return Math.hypot(xDiff, yDiff);
}

export function distanceForCollision1(objectMooving, objecCollision) {
  let size = objectMooving.radius * 2;
  if (
    Math.abs(objecCollision.x - objectMooving.x) < size &&
    objectMooving.y >= objecCollision.y - size / 2 &&
    objectMooving.y <= objecCollision.y + size / 2
  ) {
    return "x";
  }
  if (
    Math.abs(objecCollision.y - objectMooving.y) < size &&
    objectMooving.x >= objecCollision.x - size / 2 &&
    objectMooving.x <= objecCollision.x + size / 2
  ) {
    return "y";
  }
  return 0;
}

export function distanceForCollision(objectMooving, objecCollision) {
  let size = objectMooving.radius * 2;
  let radius = size / 2 - 1;
  if (
    Math.abs(objecCollision.x - objectMooving.x) < size &&
    objectMooving.y + radius >= objecCollision.y - radius &&
    objectMooving.y + radius <= objecCollision.y + radius
  ) {
    return "x";
  }
  if (
    Math.abs(objecCollision.x - objectMooving.x) < size &&
    objectMooving.y - radius >= objecCollision.y - radius &&
    objectMooving.y - radius <= objecCollision.y + radius
  ) {
    return "x";
  }
  if (
    Math.abs(objecCollision.y - objectMooving.y) < size &&
    objectMooving.x + radius >= objecCollision.x - radius &&
    objectMooving.x + radius <= objecCollision.x + radius
  ) {
    return "y";
  }
  if (
    Math.abs(objecCollision.y - objectMooving.y) < size &&
    objectMooving.x - radius >= objecCollision.x - radius &&
    objectMooving.x - radius <= objecCollision.x + radius
  ) {
    return "y";
  }
}
