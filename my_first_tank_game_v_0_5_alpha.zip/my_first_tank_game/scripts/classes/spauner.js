import { Block } from "./blocks.js";

export class Spauner extends Block {
  constructor(x, y, context) {
    super(x, y, context);
    this.image.src = "../../img/spauner.png";
    this.health = 10;
    this.imageStep = 0;
  }
  draw() {
    this.context.drawImage(
      this.image,
      0,
      0,
      this.imageWidth,
      this.imageHeight,
      this.x - this.imageWidth / 2,
      this.y - this.imageHeight / 2,
      this.imageWidth,
      this.imageHeight
    );
  }
}
