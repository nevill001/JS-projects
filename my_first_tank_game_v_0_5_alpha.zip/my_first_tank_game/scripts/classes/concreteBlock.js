import { Block } from "./blocks.js";

export class ConcreteBlock extends Block {
  constructor(x, y, context) {
    super(x, y, context);
    this.image.src = "../../img/concrete_block.png";
  }
}
