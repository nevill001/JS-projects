export class Block {
  constructor(x, y, context) {
    this.x = x;
    this.y = y;
    this.context = context;
    this.radius = 12;
    this.health = 2;
    this.image = new Image();
    this.image.src = "../../img/default_block.png";
    this.imageWidth = 24;
    this.imageHeight = 24;
  }
  draw() {
    this.health = 2;
    this.context.drawImage(
      this.image,
      0,
      0,
      this.imageWidth,
      this.imageHeight,
      this.x - this.imageWidth / 2,
      this.y - this.imageHeight / 2,
      this.imageWidth,
      this.imageHeight
    );
  }
  hit() {
    this.health -= 1;
  }
}
