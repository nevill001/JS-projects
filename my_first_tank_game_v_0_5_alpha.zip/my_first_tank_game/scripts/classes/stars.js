import { Block } from "./blocks.js";

export class Stars extends Block {
  constructor(x, y, context) {
    super(x, y, context);
    this.image.src = "../../img/star1.png";
    this.imageStep = 1;
  }
  change() {
    this.image.src = "../../img/star2.png";
    this.imageStep = 2;
  }
}
