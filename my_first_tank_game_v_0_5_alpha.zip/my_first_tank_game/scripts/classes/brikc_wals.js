import { Block } from "./blocks.js";

export class BrickWals extends Block {
  constructor(x, y, context) {
    super(x, y, context);
    this.image.src = "../../img/brick_wals.png";
    this.health = 3;
  }
  draw() {
    this.context.drawImage(
      this.image,
      this.health * this.imageWidth,
      0,
      this.imageWidth,
      this.imageHeight,
      this.x - this.imageWidth / 2,
      this.y - this.imageHeight / 2,
      this.imageWidth,
      this.imageHeight
    );
  }
  hit() {
    this.health -= 1;
  }
}
