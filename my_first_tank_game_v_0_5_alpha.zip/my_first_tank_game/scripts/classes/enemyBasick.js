export class EnemyBasick {
  constructor(x, y, context) {
    this.x = x;
    this.y = y;
    this.context = context;
    this.radius = 12;
    this.image = new Image();
    this.image.src = "../../img/tank2.png";
    this.imageWith = 24;
    this.imageHeight = 24;
    this.imageLenght = 0;
    this.velocity = 0.5;
    this.imageTick = 0;
    this.ImageTickLimit = 18;
    this.health = 3;
    this.mooving = 0;
    this.moovingLimit = 700;
  }
  draw() {
    let subX =
      this.imageTick > this.ImageTickLimit
        ? this.imageWith * 2
        : this.imageWith;
    this.imageTick++;
    if (this.imageTick > this.ImageTickLimit * 2) this.imageTick = 0;
    this.context.drawImage(
      this.image,
      subX,
      this.imageHeight * this.imageLenght,
      this.imageWith,
      this.imageHeight,
      this.x - this.imageWith / 2,
      this.y - this.imageHeight / 2,
      this.imageWith,
      this.imageHeight
    );
  }
  update() {
    this.draw();
    this.mooving++;
    if (this.imageLenght > 3) this.imageLenght = 0;
    if (this.imageLenght < 0) this.imageLenght = 3;
    if (this.mooving > this.moovingLimit) this.mooving = 0;
    if (this.mooving === 1) {
      this.imageLength = Math.floor(Math.random() * 4);
    }
    if (this.imageLenght === 0) {
      this.y -= this.velocity;
    }
    if (this.imageLenght === 1) {
      this.y += this.velocity;
    }
    if (this.imageLenght === 2) {
      this.x -= this.velocity;
    }
    if (this.imageLenght === 3) {
      this.x += this.velocity;
    }
  }
  hit() {
    this.health--;
  }
}
